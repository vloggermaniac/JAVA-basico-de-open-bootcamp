package Array;

public class ejercicio3 {

    public static void main(String[] args) {


        String[] nombre = new String[]{"Juan ", "Jose ", "Pedro"};

        for(int i = 0; i < nombre.length; i++) {
            System.out.print(nombre[i]);
        }

    }

}